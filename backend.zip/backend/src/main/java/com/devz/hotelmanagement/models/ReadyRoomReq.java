package com.devz.hotelmanagement.models;

import lombok.Data;

@Data
public class ReadyRoomReq {

    private String code;

}
