package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.SupplyType;

public interface SupplyTypeService extends ServiceBase<SupplyType> {

}
