package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.Shift;

public interface ShiftService extends ServiceBase<Shift> {

}
