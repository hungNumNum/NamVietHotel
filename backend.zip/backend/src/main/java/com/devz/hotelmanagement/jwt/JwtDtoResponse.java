package com.devz.hotelmanagement.jwt;

import lombok.Data;

@Data
public class JwtDtoResponse {

    private String token;

}
