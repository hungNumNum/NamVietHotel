package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.Setting;

public interface SettingService {

    Setting getSetting();

    Setting update(Setting setting);

}
