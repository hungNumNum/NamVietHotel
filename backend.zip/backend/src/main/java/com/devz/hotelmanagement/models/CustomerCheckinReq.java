package com.devz.hotelmanagement.models;

import lombok.Data;

@Data
public class CustomerCheckinReq {

    private Integer customerId;

}
