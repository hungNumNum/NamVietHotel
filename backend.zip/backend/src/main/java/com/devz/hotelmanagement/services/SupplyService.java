package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.Supply;

public interface SupplyService extends ServiceBase<Supply> {

}
