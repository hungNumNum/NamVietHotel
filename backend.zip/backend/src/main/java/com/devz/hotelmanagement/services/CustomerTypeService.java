package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.CustomerType;

public interface CustomerTypeService extends ServiceBase<CustomerType> {

}
