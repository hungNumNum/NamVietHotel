package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.Role;

public interface RoleService extends ServiceBase<Role> {

}
