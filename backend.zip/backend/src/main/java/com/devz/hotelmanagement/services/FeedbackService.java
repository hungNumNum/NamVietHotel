package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.Feedback;

public interface FeedbackService extends ServiceBase<Feedback> {

}
