package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.BedType;

public interface BedTypeService extends ServiceBase<BedType> {

}
