package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.ServiceType;

public interface ServiceTypeService extends ServiceBase<ServiceType> {

}
