package com.devz.hotelmanagement.models;

import lombok.Data;

@Data
public class CancelRoomReq {

    private String code;
    private String note;

}
