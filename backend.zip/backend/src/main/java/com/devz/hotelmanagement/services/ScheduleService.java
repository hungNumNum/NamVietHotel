package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.Schedule;

public interface ScheduleService extends ServiceBase<Schedule> {

}
