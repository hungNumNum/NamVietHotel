package com.devz.hotelmanagement.services;

import com.devz.hotelmanagement.entities.BookingDetail;
import com.devz.hotelmanagement.entities.BookingDetailHistory;

import java.util.List;

public interface BookingDetailHistoryService extends ServiceBase<BookingDetailHistory> {

    List<BookingDetailHistory> findByBookingHistoryId(Integer id);

}
